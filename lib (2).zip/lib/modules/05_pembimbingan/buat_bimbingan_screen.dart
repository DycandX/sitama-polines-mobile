import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:provider/provider.dart';

import '../../services/api_service.dart';
import '../05_pembimbingan/buat_bimbingan_controller.dart';

class BuatBimbinganScreen extends StatefulWidget {
  final Function(String title, String description, String? file, String? dosen)
      onSave;

  const BuatBimbinganScreen({super.key, required this.onSave});

  @override
  State<BuatBimbinganScreen> createState() => _BuatBimbinganScreenState();
}

class _BuatBimbinganScreenState extends State<BuatBimbinganScreen> {
  final _formKey = GlobalKey<FormState>();

  final List<String> dosenList = [];

  String? selectedFile;
  String title = '';
  String description = '';
  String? selectedDosen;

  // API fetch data
  String? mhsNama;
  int? mhsNim;
  String? ta_judul;
  String? pembimbing1_nama;
  String? pembimbing2_nama;
  String? pembimbing1_nip;
  String? pembimbing2_nip;

  bool isLoading = true;

  Future<void> loadMahasiswaData(String token) async {
    try {
      final data = await ApiService.fetchMahasiswa(token);
      setState(() {
        // Data mahasiswa dasar
        mhsNama = data['data']['mhs_nama'];
        mhsNim = data['data']['mhs_nim'];
        ta_judul = data['data']['ta_judul'];

        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;

        // Optional: Set default values on error
        pembimbing1_nama = "-";
        pembimbing1_nip = "-";
        pembimbing2_nama = "-";
        pembimbing2_nip = "-";
      });
      print('Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();

    final token = Provider.of<AuthProvider>(context, listen: false).token;
    if (token != null) {
      loadMahasiswaData(token);
    } else {
      print('User is not authenticated');
    }
  }
  // End of API Code
  
  get pembimbing => null;

  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();

    if (result != null) {
      setState(() {
        selectedFile = result.files.single.name;
      });
    }
  }

  void _saveForm() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      widget.onSave(title, description, selectedFile, selectedDosen);
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 10, // Adjusted for better alignment
        toolbarHeight: 10, // Adjusted height for better header presentation
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: const Color.fromRGBO(40, 42, 116, 1),
                            ),
                            child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.arrow_back, color: Colors.white),
                            ),
                          ),
                          const SizedBox(width: 100),
                          const Text(
                            'sss',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                      CircleAvatar(
                        backgroundColor: Colors.grey[200],
                        child: const Icon(Icons.person, color: Colors.black),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Buat Bimbingan',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Judul Bimbingan',
                            filled: true,
                            fillColor: Colors.grey[200],
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: BorderSide.none,
                            ),
                          ),
                          validator: (value) {
                            return value == null || value.isEmpty
                                ? 'Field ini harus diisi'
                                : null;
                          },
                          onSaved: (value) => title = value!,
                        ),
                        const SizedBox(height: 10),

                        // Dropdown for selecting Dosen
                        DropdownButtonFormField<String>(
                          value: selectedDosen,
                          decoration: InputDecoration(
                            labelText: 'Pilih Pembimbing',
                            filled: true,
                            fillColor: Colors.grey[200],
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: BorderSide.none,
                            ),
                          ),
                          items: dosenList.map((dosen) {
                            return DropdownMenuItem(
                              value: dosen,
                              child: Text(dosen),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              selectedDosen = value;
                            });
                          },
                          validator: (value) {
                            return value == null
                                ? 'Silahkan pilih dosen'
                                : null;
                          },
                        ),

                        const SizedBox(height: 10),
                        GestureDetector(
                          onTap: _pickFile,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                vertical: 16.0, horizontal: 12.0),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  selectedFile ?? 'File Lampiran',
                                  style: TextStyle(
                                    color: selectedFile != null
                                        ? Colors.black87
                                        : Colors.grey,
                                    fontStyle: selectedFile == null
                                        ? FontStyle.italic
                                        : FontStyle.normal,
                                  ),
                                ),
                                const Icon(Icons.upload_file,
                                    color: Colors.grey),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          maxLines: 3,
                          decoration: InputDecoration(
                            labelText: 'Deskripsi',
                            filled: true,
                            fillColor: Colors.grey[200],
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(8.0),
                              borderSide: BorderSide.none,
                            ),
                          ),
                          validator: (value) {
                            return value == null || value.isEmpty
                                ? 'Field ini harus diisi'
                                : null;
                          },
                          onSaved: (value) => description = value!,
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _saveForm,
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  const Color.fromRGBO(27, 175, 27, 1),
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14.0),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                            ),
                            child: const Text(
                              'Simpan',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
