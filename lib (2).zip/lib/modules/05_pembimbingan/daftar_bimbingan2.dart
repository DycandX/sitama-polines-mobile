import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../services/api_service.dart';
import '../05_pembimbingan/daftar_bimbingan_controller.dart';

class DaftarBimbingan2 extends StatefulWidget {
  final String pembimbing;

  const DaftarBimbingan2({required this.pembimbing, super.key});

  @override
  _DaftarBimbingan2State createState() => _DaftarBimbingan2State();
}

class _DaftarBimbingan2State extends State<DaftarBimbingan2> {
  List<Map<String, String?>> revisiList = [];
  int revisionCount = 0; // Counter for revisions

  void _addRevisi(
      String title, String description, String? file, String? dosen, String? verified) {
    setState(() {
      revisionCount += 1; // Increment revision count for each new entry
      revisiList.add({
        'title': title,
        'description': description,
        'file': file,
        'dosen': dosen,
        'revisionNumber': 'Bimbingan ke-$revisionCount',
        'verified': verified,
      });
    });
  }

  // API fetch data
  String? mhsNama;
  String? pembimbing1_nama;
  String? pembimbing1_nip;

  bool isLoading = true;

  Future<void> loadMahasiswaData(String token) async {
    try {
      final data = await ApiService.fetchMahasiswa(token);

      setState(() {
        // Initialize default values for the fields

        pembimbing1_nama = null;
        pembimbing1_nip = null;

        // Assuming the response contains a list under 'logCollect'
        var logCollect = data['logCollect'] as List? ?? []; // Safe access

        logCollect.forEach((logItem) {
          if (logItem is Map<String, dynamic> && logItem['urutan'] == 2) {
            String title = logItem['bimb_judul'] ?? "";
            String description = logItem['bimb_desc'] ?? "";
            String? file = logItem['download_url'] ?? null;
            String? dosen = logItem['dosen_nama'] ?? "";
            String? verified = (logItem['bimb_status'] ?? 0).toString();

            _addRevisi(title, description, file, dosen, verified);

            pembimbing1_nama = logItem['dosen_nama'] ?? pembimbing1_nama;
            pembimbing1_nip = logItem['dosen_nip'] ?? pembimbing1_nip;
          }
        });

        mhsNama = data['data']?['mhs_nama'] ?? "-";


        if (data['data']?['mahasiswa']?['dosen'] != null &&
            (data['data']['mahasiswa']['dosen'] as List).isNotEmpty) {
          pembimbing1_nama = data['data']['mahasiswa']['dosen'][0]['dosen_nama'] ?? "-";
          pembimbing1_nip = data['data']['mahasiswa']['dosen'][0]['dosen_nip'] ?? "-";
        } else {
          pembimbing1_nama = "-";
          pembimbing1_nip = "-";
        }

        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();

    final token = Provider.of<AuthProvider>(context, listen: false).token;
    if (token != null) {
      loadMahasiswaData(token);
    } else {
      print('User is not authenticated');
    }
  }

  @override
  Widget build(BuildContext context) {
    print(revisiList);
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 10, // Adjusted for better alignment
        toolbarHeight: 10, // Adjusted height for better header presentation
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Back Button, Name, and Profile Picture Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: const Color.fromRGBO(40, 42, 116, 1),
                            ),
                            child: IconButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              icon: const Icon(Icons.arrow_back, color: Colors.white),
                            ),
                          ),
                          const SizedBox(width: 100),
                          Text(
                            mhsNama ?? 'Loading...',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                      CircleAvatar(
                        backgroundColor: Colors.grey[200],
                        child: const Icon(Icons.person, color: Colors.black),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Daftar Bimbingan',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Expanded List Container
                  Expanded(
                    child: revisiList.isEmpty
                        ? const Center(child: Text('Belum ada bimbingan yang dibuat.'))
                        : ListView.builder(
                      itemCount: revisiList.length,
                      itemBuilder: (context, index) {
                        final revisi = revisiList[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10.0),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            elevation: 2,
                            child: ListTile(
                              title: Text(
                                revisi['title'] ?? 'Judul Tidak Tersedia',
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    revisi['revisionNumber'] ?? '',
                                    style: const TextStyle(
                                      color: Colors.black54,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Container(
                                        width: 8,
                                        height: 8,
                                        decoration: BoxDecoration(
                                          color: revisi['verified'] == '1'
                                              ? Colors.green
                                              : Colors.yellow,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        revisi['verified'] == '1'
                                            ? 'Sudah Diverifikasi'
                                            : 'Belum Diverifikasi',
                                        style: TextStyle(
                                          color: revisi['verified'] == '1'
                                              ? Colors.green
                                              : Colors.yellow,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  if (revisi['dosen'] != null) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      'Dosen: ${revisi['dosen']}',
                                      style: const TextStyle(color: Colors.black54),
                                    ),
                                  ],
                                ],
                              ),
                              trailing: ElevatedButton(
                                onPressed: () {
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue,
                                ),
                                child: const Text(
                                  'Lihat',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 20),
                  // SizedBox(
                  //   width: double.infinity,
                  //   child: ElevatedButton(
                  //     onPressed: () {
                  //       Navigator.push(
                  //         context,
                  //         MaterialPageRoute(
                  //           builder: (context) =>
                  //               BuatRevisiScreen(onSave: _addRevisi),
                  //         ),
                  //       );
                  //     },
                  //     style: ElevatedButton.styleFrom(
                  //       backgroundColor: const Color.fromRGBO(27, 175, 27, 1),
                  //       padding: const EdgeInsets.symmetric(vertical: 14.0),
                  //       shape: RoundedRectangleBorder(
                  //         borderRadius: BorderRadius.circular(8.0),
                  //       ),
                  //     ),
                  //     child: const Text(
                  //       '+ Buat Revisi',
                  //       style: TextStyle(
                  //         fontSize: 16,
                  //         fontWeight: FontWeight.bold,
                  //         color: Colors.white,
                  //       ),
                  //     ),
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
