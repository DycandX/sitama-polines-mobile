import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

import '../../services/api_service.dart';
import '../05_pembimbingan/daftar_bimbingan_controller.dart';
import 'package:http/http.dart' as http;

class PdfViewerScreen extends StatelessWidget {
  final String pdfPath;

  const PdfViewerScreen({Key? key, required this.pdfPath}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("PDF Viewer"),
      ),
      body: PDFView(
        filePath: pdfPath,
        enableSwipe: true,
        swipeHorizontal: true,
        autoSpacing: true,
        pageFling: true,
      ),
    );
  }
}

Future<void> downloadAndOpenPdf(BuildContext context, String url, String fileName) async {
  try {
    final Directory directory = await getTemporaryDirectory();
    final String filePath = '${directory.path}/$fileName';

    // Cek apakah file sudah diunduh
    final File file = File(filePath);
    if (!await file.exists()) {
      Dio dio = Dio();
      await dio.download(url, filePath);
    }

    // Navigasi ke PDF Viewer
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PdfViewerScreen(pdfPath: filePath),
      ),
    );
  } catch (e) {
    print("Error downloading or opening PDF: $e");
  }
}

class DaftarBimbinganScreen extends StatefulWidget {
  const DaftarBimbinganScreen({super.key, required String pembimbing});

  @override
  State<DaftarBimbinganScreen> createState() => _DaftarBimbinganScreenState();
}

class _DaftarBimbinganScreenState extends State<DaftarBimbinganScreen> {
  List<Map<String, String?>> revisiList = [];
  int revisionCount = 0; // Counter for revisions

  void _addRevisi(
      String title, String description, String? file, String? dosen, String? verified) {
    setState(() {
      revisionCount += 1; // Increment revision count for each new entry
      revisiList.add({
        'title': title,
        'description': description,
        'file': file,
        'dosen': dosen,
        'revisionNumber': 'Bimbingan ke-$revisionCount',
        'verified': verified,
      });
    });
  }

  // API fetch data
  String? mhsNama;
  String? pembimbing1_nama;
  String? pembimbing1_nip;

  bool isLoading = true;

  Future<void> loadMahasiswaData(String token) async {
    try {
      final data = await ApiService.fetchMahasiswa(token);

      setState(() {
        // Initialize default values for the fields

        pembimbing1_nama = null;
        pembimbing1_nip = null;

        // Assuming the response contains a list under 'logCollect'
        var logCollect = data['logCollect'] as List? ?? []; // Safe access

        logCollect.forEach((logItem) {
          if (logItem is Map<String, dynamic> && logItem['urutan'] == 1) {
            String title = logItem['bimb_judul'] ?? "";
            String description = logItem['bimb_desc'] ?? "";
            String? file = logItem['download_url'] ?? null;
            String? dosen = logItem['dosen_nama'] ?? "";
            String? verified = (logItem['bimb_status'] ?? 0).toString();

            _addRevisi(title, description, file, dosen, verified);

            pembimbing1_nama = logItem['dosen_nama'] ?? pembimbing1_nama;
            pembimbing1_nip = logItem['dosen_nip'] ?? pembimbing1_nip;
          }
        });

        mhsNama = data['data']?['mhs_nama'] ?? "-";


        if (data['data']?['mahasiswa']?['dosen'] != null &&
            (data['data']['mahasiswa']['dosen'] as List).isNotEmpty) {
          pembimbing1_nama = data['data']['mahasiswa']['dosen'][0]['dosen_nama'] ?? "-";
          pembimbing1_nip = data['data']['mahasiswa']['dosen'][0]['dosen_nip'] ?? "-";
        } else {
          pembimbing1_nama = "-";
          pembimbing1_nip = "-";
        }

        isLoading = false;
      });
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      print('Error: $e');
    }
  }

  @override
  void initState() {
    super.initState();

    final token = Provider.of<AuthProvider>(context, listen: false).token;
    if (token != null) {
      loadMahasiswaData(token);
    } else {
      print('User is not authenticated');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 10, // Adjusted for better alignment
        toolbarHeight: 10, // Adjusted height for better header presentation
      ),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Back Button, Name, and Profile Picture Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back, color: Colors.blue),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                          const SizedBox(width: 100),
                          Text(
                            mhsNama ?? 'Nama Tidak Diketahui',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                            ),
                          ),
                        ],
                      ),
                      CircleAvatar(
                        backgroundColor: Colors.grey[200],
                        child: const Icon(Icons.person, color: Colors.black),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Daftar Bimbingan',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Expanded List Container
                  Expanded(
                    child: revisiList.isEmpty
                        ? const Center(child: Text('Belum ada bimbingan yang dibuat.'))
                        : ListView.builder(
                      itemCount: revisiList.length,
                      itemBuilder: (context, index) {
                        final revisi = revisiList[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 10.0),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            elevation: 2,
                            child: ListTile(
                              title: Text(
                                revisi['title'] ?? 'Judul Tidak Tersedia',
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    revisi['revisionNumber'] ?? '',
                                    style: const TextStyle(
                                      color: Colors.black54,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Container(
                                        width: 8,
                                        height: 8,
                                        decoration: BoxDecoration(
                                          color: revisi['verified'] == '1'
                                              ? Colors.green
                                              : Colors.yellow,
                                          shape: BoxShape.circle,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        revisi['verified'] == '1'
                                            ? 'Sudah Diverifikasi'
                                            : 'Belum Diverifikasi',
                                        style: TextStyle(
                                          color: revisi['verified'] == '1'
                                              ? Colors.green
                                              : Colors.yellow,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  if (revisi['dosen'] != null) ...[
                                    const SizedBox(height: 4),
                                    Text(
                                      'Dosen: ${revisi['dosen']}',
                                      style: const TextStyle(color: Colors.black54),
                                    ),
                                  ],
                                ],
                              ),
                              trailing: ElevatedButton(
                                onPressed: () {
                                  final String pdfUrl = '${Config.baseUrl}${revisi['file']}';
                                  final String fileName = revisi['file'] ?? 'document.pdf'; // Default file name
                                  downloadAndOpenPdf(context, pdfUrl, fileName);
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue,
                                ),
                                child: const Text(
                                  'Lihat',
                                  style: TextStyle(color: Colors.white),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
