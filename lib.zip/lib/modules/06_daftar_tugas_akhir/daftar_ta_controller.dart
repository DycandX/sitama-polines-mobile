import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _baseUrl = 'http://sitama-new.test/api/v1/';

  static Future<Map<String, dynamic>> fetchMahasiswa(String token) async {
    final url = Uri.parse('${_baseUrl}daftar-tugas-akhir');

    try {
      final response = await http.get(
        url,
        headers: {
          'Authorization': 'Bearer $token',
          'Content-Type': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
            'Failed to fetch data. Status code: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error fetching data: $e');
    }
  }
}

class DaftarTAController {
  List<TugasAkhirItem> daftarTugas = [
    TugasAkhirItem(
      namaDokumen: 'Surat Keterangan Magang',
      status: 'Menunggu Divalidasi',
      isUploaded: true,
    ),
    TugasAkhirItem(
      namaDokumen: 'Surat Keterangan KKL',
      status: 'Belum Upload',
      isUploaded: false,
    ),
    TugasAkhirItem(
      namaDokumen: 'Sertifikat TOEIC',
      status: 'Menunggu Divalidasi',
      isUploaded: true,
    ),
    TugasAkhirItem(
      namaDokumen: 'Naskah Tugas Akhir/Skripsi',
      status: 'Menunggu Divalidasi',
      isUploaded: true,
    ),
    TugasAkhirItem(
      namaDokumen: 'Surat Keterangan Selesai Bimbingan',
      status: 'Diverifikasi',
      isUploaded: true,
    ),
    TugasAkhirItem(
      namaDokumen: 'Form Keterangan Siap Ujian',
      status: 'Diverifikasi',
      isUploaded: true,
    ),
    TugasAkhirItem(
      namaDokumen: 'Sertifikasi Kompetisi (Oracle, Mtcna, Dll)',
      status: 'Diverifikasi',
      isUploaded: true,
    ),
    // Tambahkan item lain sesuai kebutuhan
  ];

  // Logic to check if all requirements are verified
  void checkSyarat(BuildContext context) {
    bool allVerified = daftarTugas.every((item) => item.status == 'Diverifikasi');

    if (allVerified) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Semua syarat telah diverifikasi, Anda bisa mendaftar sidang')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Semua syarat belum terpenuhi')),
      );
    }
  }
}

class TugasAkhirItem {
  String namaDokumen;
  String status;
  bool isUploaded;

  TugasAkhirItem({
    required this.namaDokumen,
    required this.status,
    required this.isUploaded,
  });

  // Function to get color based on status
  Color getColorIndicator() {
    if (status == 'Diverifikasi') return Colors.green;
    if (status == 'Menunggu Divalidasi') return Colors.yellow;
    return Colors.red; // For 'Belum Upload'
  }
}
