import 'package:flutter/material.dart';
import 'package:pbl_sitama/modules/03_home_mahasiswa/home_mahasiswa_controller.dart';
import 'package:pbl_sitama/modules/07_sidang_tugas_akhir/revisi_tugas_akhir/daftar_revisi.dart';
import 'package:pbl_sitama/services/api_service.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';

class SidangTaScreen extends StatefulWidget {
  const SidangTaScreen({super.key});
  @override
  _SidangTaScreenState createState() => _SidangTaScreenState();
}

class _SidangTaScreenState extends State<SidangTaScreen> {
  String? mhsNama;
  String? pembimbing1;
  String? pembimbing2;
  String? penguji1;
  String? penguji2;
  String? penguji3;
  String? sekretaris;
  String? thnAkademik;
  String? judulTA;
  String? tglSidang;
  String? ruangSidang;
  String? sesiSidang;

  Future<void> loadMahasiswaData(String token) async {
    try {
      final data = await ApiService.fetchMahasiswa(token);

      setState(() {
        mhsNama = data['data']['mahasiswa']['mhs_nama'];
        pembimbing1 = data['data']['mahasiswa']['dosen'][0]['dosen_nama'];
        pembimbing2 = data['data']['mahasiswa']['dosen'][1]['dosen_nama'];
        penguji1 = data['data']['mahasiswa']['penguji'][0]['penguji_nama'];
        penguji2 = data['data']['mahasiswa']['penguji'][1]['penguji_nama'];
        penguji3 = data['data']['mahasiswa']['penguji'][2]['penguji_nama'];
        sekretaris = data['data']['mahasiswa']['sekre'];
        thnAkademik = data['data']['mahasiswa']['tahun_akademik'];
        judulTA = data['data']['mahasiswa']['judul_final'];
        tglSidang = data['data']['mahasiswa']['tgl_sidang'];
        ruangSidang = data['data']['mahasiswa']['ruangan_nama'];
        sesiSidang = data['data']['mahasiswa']['sesi_nama'];
      });
    } catch (e) {
      print('Error: $e');

      setState(() {});
    }
  }

  @override
  void initState() {
    super.initState();

    final token = Provider.of<AuthProvider>(context, listen: false).token;
    if (token != null) {
      loadMahasiswaData(token);
    } else {
      print('User is not authenticated');
    }
  }

  String _getStatusText() {
    if (tglSidang == null) return 'Loading . . .';

    try {
      final DateTime sidangDate = DateFormat('yyyy-MM-dd').parse(tglSidang!);
      final DateTime currentDate = DateTime.now();

      if (currentDate.isAfter(sidangDate)) {
        return 'Sudah Sidang';
      } else {
        return 'Belum Sidang';
      }
    } catch (e) {
      return 'Invalid Date';
    }
  }

  Color _getStatusColor() {
    if (tglSidang == null) return Colors.grey;

    try {
      final DateTime sidangDate = DateFormat('yyyy-MM-dd').parse(tglSidang!);
      final DateTime currentDate = DateTime.now();

      if (currentDate.isAfter(sidangDate)) {
        return Colors.green; // Warna hijau untuk Sudah Sidang
      } else {
        return Colors.red; // Warna merah untuk Belum Sidang
      }
    } catch (e) {
      return Colors.grey; // Warna default untuk kesalahan parsing
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 10,
        toolbarHeight: 10,
        backgroundColor: Colors.indigo[900],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Transform.translate(
                  offset: Offset(-20, 0),
                  child: RawMaterialButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    elevation: 2.0,
                    fillColor: Colors.indigo[900],
                    padding: EdgeInsets.all(15.0),
                    shape: CircleBorder(),
                    child: Icon(
                      Icons.arrow_back,
                      size: 15.0,
                      color: Colors.white,
                    ),
                  ),
                ),
                Spacer(),
                Row(
                  children: [
                    SizedBox(width: 30),
                    Text(
                      mhsNama ?? "Loading..",
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    SizedBox(width: 10),
                    CircleAvatar(
                      radius: 25,
                      backgroundColor: Colors.grey[200],
                      child: Icon(Icons.person, size: 30, color: Colors.black),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 30),
            Text(
              'Sidang',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
            Text(
              'Tugas Akhir',
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
            SizedBox(height: 20),
            CustomExpansionCard(
              title: 'Data Sidang Tugas Akhir',
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomTextField(
                          label: 'Pembimbing 1',
                          placeholderText: pembimbing1 ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Pembimbing 2',
                          placeholderText: pembimbing2 ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Penguji 1',
                          placeholderText: penguji1 ?? 'Belum Di Plotting'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Penguji 2',
                          placeholderText: penguji2 ?? 'Belum Di Plotting'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Penguji 3',
                          placeholderText: penguji3 ?? 'Belum Di Plotting'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Sekretaris',
                          placeholderText: sekretaris ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Tahun Akademik',
                          placeholderText: thnAkademik ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Judul Tugas Akhir',
                          placeholderText: judulTA ?? 'Loading . . .',
                          ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 15),
            CustomExpansionCard(
              title: 'Status',
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16.0, vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomTextField(
                          label: 'Tanggal Sidang',
                          placeholderText: tglSidang ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Ruang Sidang',
                          placeholderText: ruangSidang ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                          label: 'Sesi Sidang',
                          placeholderText: sesiSidang ?? 'Loading . . .'),
                      SizedBox(height: 10),
                      CustomTextField(
                        label: 'Status Sidang',
                        placeholderText: _getStatusText(),
                        isEditable: false,
                        style: TextStyle(
                          color:
                              _getStatusColor(), // Warna teks berdasarkan status
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 10),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => DaftarRevisiScreen(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                ),
                child: Text(
                  'Revisi',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CustomExpansionCard extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const CustomExpansionCard(
      {super.key, required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Theme(
        data: ThemeData().copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          leading: Icon(Icons.menu, size: 24, color: Colors.black),
          title: Text(
            title,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          childrenPadding: EdgeInsets.symmetric(horizontal: 16.0),
          trailing: Icon(Icons.arrow_drop_down, size: 24, color: Colors.black),
          children: children,
        ),
      ),
    );
  }
}

class CustomTextField extends StatelessWidget {
  final String label;
  final int maxLines;
  final String? placeholderText;
  final bool isEditable;
  final TextStyle? style; // Tambahkan parameter style

  const CustomTextField({
    super.key,
    required this.label,
    this.maxLines = 1,
    this.placeholderText,
    this.isEditable = true,
    this.style, // Inisialisasi parameter style
  });

  @override
  Widget build(BuildContext context) {
    bool isPlaceholder = placeholderText != null;
    return Container(
      margin: EdgeInsets.only(bottom: 8.0), // Adjust spacing between fields
      child: TextField(
        maxLines: maxLines,
        readOnly: true,
        controller:
            isPlaceholder ? TextEditingController(text: placeholderText) : null,
        style: style ??
            TextStyle(
              fontStyle: FontStyle.normal,
              color: Colors.black87,
            ), // Gunakan style jika tersedia
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(color: Colors.grey),
          filled: true,
          fillColor: Colors.grey[200], // Background color to match the image
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(5),
            borderSide: BorderSide.none, // Remove border
          ),
        ),
      ),
    );
  }
}

